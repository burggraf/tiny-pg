ALTER TABLE pgsodium.key ADD COLUMN user_data text;  -- deprecated for b/w compat with <= 3.0.4
