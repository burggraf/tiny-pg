
INSERT INTO pgsodium.key (status, key_id, key_context, comment)
VALUES ('default', 1, 'pgsodium', 'This is the default key used for vault.secrets');
